#ifndef _TESTVECTORS_SMALL_H
#define _TESTVECTORS_SMALL_H


extern void subBytesASM(uint8_t* state);

extern void mixBytesAsm(uint32_t* halfstate);








#endif
