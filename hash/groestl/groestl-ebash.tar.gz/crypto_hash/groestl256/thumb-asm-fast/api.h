// Implementation of Gröstl 256 Bit hash function
// Author: Thomas Krinninger
//         Student at Graz University of technology

#define CRYPTO_BYTES 32

#define CRYPTO_VERSION "1.0"
