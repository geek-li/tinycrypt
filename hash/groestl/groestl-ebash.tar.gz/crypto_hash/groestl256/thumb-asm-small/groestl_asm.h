#ifndef _GROESTL_ASM_H
#define _GROESTL_ASM_H


extern void mixBytesAsm(uint32_t* halfstate);








#endif
