
// specify assembly or intrinsics implementation
// #define TASM
#define TINTR

// specify AES-NI, AVX (with AES-NI) or vector-permute implementation
// #define VAES
// #define VAVX
#define VVPERM
