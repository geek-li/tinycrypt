Contents                                                       Description
--------------------------------------------------------------------------------------------


\Supporting Documentation
      jh20110116.pdf  ------------------------------------  The latest version of the JH document
      Round3Mods.pdf -------------------------------------  The changes made comparing to the original version 
      cover20110116.pdf  ---------------------------------  Cover sheet

\Reference Implementation
      jh_ref.h  ------------------------------------------  Reference implementation of JH

\Optimized_32 bit
      jh_ansi_opt32.h  -----------------------------------  Optimized implementation, bitslice, 32-bit platform

\Optimized_64 bit
      jh_ansi_opt64.h ------------------------------------  Optimized implementation, bitslice, 64-bit platform
      
\Additional_Implementations
      jh_sse2_opt64.h ------------------------------------  Optimized implementation, SSE2, bitslice, 64-bit platform
      jh_sse2_opt32.h ------------------------------------  Optimized implementation, SSE2, bitslice, 32-bit platform
      jh_bitslice_ref32.h --------------------------------  Reference implementation, bitslice, 32-bit platform
      jh_bitslice_ref64.h --------------------------------  Reference implementation, bitslice, 64-bit platform
      jh_opt8.h ------------------------------------------  Optimized implementation, 8-bit platform

\KAT_MCT   -----------------------------------------------  KAT and MCT results for JH-224, JH-256, JH-384 and JH-512 
      ShortMsgKAT_224.txt
      LongMsgKAT_224.txt
      ExtremelyLongMsgKAT_224.txt
      MonteCarlo_224.txt
      ShortMsgKAT_256.txt
      LongMsgKAT_256.txt
      ExtremelyLongMsgKAT_256.txt
      MonteCarlo_256.txt
      ShortMsgKAT_384.txt
      LongMsgKAT_384.txt
      ExtremelyLongMsgKAT_384.txt
      MonteCarlo_384.txt
      ShortMsgKAT_512.txt
      LongMsgKAT_512.txt
      ExtremelyLongMsgKAT_512.txt
      MonteCarlo_512.txt
 
\README                                                         
      readme.txt  -----------------------------------------  This file
      