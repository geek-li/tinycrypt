/*
  javabbs.java: a simple test for the BlumBlumShub class

  Copyright 2015 Maria Morisot.

  This file is released under the GPL.

  BlumBlumShub is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License,
  or (at your option) any later version.

  BlumBlumShub is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
  for more details.

  You should have received a copy of the GNU General Public License
  along with BlumBlumShub; see the file LICENSE.  If not, write to
  the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

import java.io.*;
import java.math.BigInteger;
import BlumBlumShub;
import java.util.ArrayList;

class javabbs
{
    static int keylen = 1024;

    static int mybase = 2; /* real binary data :) */
    static int howmany = 10; /* ten randoms */
    public static void main (String[] argv)
    {
	int i, bsz;
	ArrayList randint;
	BigInteger TWO = BigInteger.ONE.add(BigInteger.ONE);
	BlumBlumShub bbs = new BlumBlumShub(keylen);

	/* generate random bytes and store them in rbyt[] */
	byte rbyt[] = bbs.randBytes(1024*1024);
	System.out.println("generated 1MB random data");

	/* generate random numbers in a given base */
	randint = bbs.randInt(mybase, howmany);

	/* hopefully it is == howmany */
	bsz = randint.size();

	for (i=0;i<bsz;i++)
	    {
		System.out.print(randint.get(i));
		if (i != (bsz-1))
		    System.out.print(" ");
		else
		    System.out.print("\n");
	    }
    }
}
