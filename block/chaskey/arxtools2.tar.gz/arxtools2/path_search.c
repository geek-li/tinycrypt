/* 
 *  Path search for Skein-256
 *
 *  Anonymous code accompanying CRYPTO 2013 sumbission #321
 *
 *  Please do not distribute this anonymized code.
 *  
 *  This code with be made available in the public domain (CC0 dedication)
 *  when the final version of the paper is published.
 */


#define _XOPEN_SOURCE 700

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <assert.h>
#include <setjmp.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#ifndef _WIN32
#include <sys/mman.h>
#else
#include "mmap_windows.c"
#endif

#define tabsize(t) (sizeof(t)/sizeof((t)[0]))
#define MIN(a,b) ((a)<(b)?(a):(b))

typedef int16_t state_t;

#ifdef DEBUG
#define print_tab2(t,n) do {                            \
    printf ("Table %s:\n", #t);                         \
    for (unsigned int i__=0; i__<n; i__++)              \
      printf ("  %08x", t[i__]);                        \
    printf ("\n");                                      \
  } while(0)

#define print_var(v)                            \
  printf("Var %s: %08x\n", #v, v)

#define log_var(v,log) do {                     \
    printf("Var %s: %08x\n", #v, v);            \
    *(log++) = v;                               \
  } while(0)
#else
#define print_tab2(t,n)
#define print_var(v)
#define log_var(v,log)
#endif

#define print_tab(t) print_tab2(t, tabsize(t))


#define rotl32(x,n)   (((x) << (n)) | ((x) >> (32 - (n))))
#define rotr32(x,n)   (((x) >> (n)) | ((x) << (32 - (n))))

#define rotl64(x,n)   (((x) << (n)) | ((x) >> (64 - (n))))
#define rotr64(x,n)   (((x) >> (n)) | ((x) << (64 - (n))))


unsigned long long cnt = 0;
int best_s2 = -1;
unsigned int s2_stat[33] = {0};

int best_s1 = -1;
unsigned int s1_stat[33] = {0};

double cost;

#define MAX_PARAMS 6  // Increase if needed
#define MAX_EQUATIONS 8

typedef struct {
  struct reg *r;
  unsigned int rot;
} parameter;

typedef uint64_t word;
#define MAX_WORD_SIZE ((int)(8*sizeof(word)))
#define WORD_SIZE 64
#define MAX_WEIGHT 12
#define WORD_MASK ((1ULL<<WORD_SIZE)-1)
#define ROTL(x,i) ( (((x)<<(i%WORD_SIZE)) | ((x)>>(WORD_SIZE-(i%WORD_SIZE)))) \
                    & WORD_MASK )

#define STATE_SIZE 4
#define CSTR_BITS 32
typedef uint32_t state_bf;

typedef struct {
  uint32_t nb_states;
  uint32_t nb_params;
  uint32_t sparse_size;
  state_bf data[];
} sparse_automaton_t;

enum eq_type {
  EQ_ADD,
  EQ_XOR,
  EQ_QUAD,
  EQ_EQ,
  EQ_XOR4,
  EQ_NONE,
  EQ_LIN,
  EQ_COUNT,
  EQ_XOR5X,
  EQ_TYPES,
};


typedef struct {
  parameter p[MAX_PARAMS];
  enum eq_type t;
  unsigned int exists:1, dirty: 1;
} equation;

typedef struct reg {
  state_bf bits[MAX_WORD_SIZE];
  equation *eq[MAX_EQUATIONS];
  unsigned int exists:1, nb_eq: 4;
} reg;

typedef struct {
  reg *a, *b;
} reg_pair;

typedef struct {
  reg *a, *b, *c, *d;
} reg_quad;

typedef struct {
  reg *x[STATE_SIZE];
} reg_state;

typedef struct {
  int nb_regs;
  int nb_eqs;
  int max_regs;
  int max_eqs;
  reg* regs;
  equation* eqs;
} syst;

typedef struct {
  unsigned int bad;
  unsigned int nb;
  state_t prev;
  char c;
} path_data;

// typedef used for counting solutions
// should allows relatively large numbers with good precision
typedef long double bignum;
// Recent GCC also support __float128
// typedef __float128 bignum;

typedef struct {
  bignum count;
} path_data_proba;


// Describe the set of constraints

enum constraints {
  CONSTR_IMPOSSIBLE = 0,
  CONSTR_ONE    = 0x000000ff,
  CONSTR_DOWN   = 0x0000ff00,
  CONSTR_XC     = 0x0000ffff,
  CONSTR_UP     = 0x00ff0000,
  CONSTR_XA     = 0x00ff00ff,
  CONSTR_NEQ    = 0x00ffff00,
  CONSTR_XE     = 0x00ffffff,
  CONSTR_ZERO   = 0xff000000,
  CONSTR_EQ     = 0xff0000ff,
  CONSTR_X5     = 0xff00ff00,
  CONSTR_XD     = 0xff00ffff,
  CONSTR_X3     = 0xffff0000,
  CONSTR_XB     = 0xffff00ff,
  CONSTR_X7     = 0xffffff00,
  CONSTR_UNKOWN = 0xffffffff,

  CONSTR_SAME   = 0xf000000f,
  CONSTR_DIFF   = 0x0f0000f0,
  CONSTR_XSAME  = 0x00f00f00,
  CONSTR_XDIFF  = 0x000ff000,

  CONSTR_X      = 0xff3c3cff,
  CONSTR_CARRY  = 0xdb2424db,
  CONSTR_Y      = 0x24181824,
  CONSTR_UCARRY = 0xcf3030cf,
  CONSTR_NCARRY = 0xf30c0cf3,

  CONSTR_NOTU   = ~CONSTR_UCARRY, // 0x30cfcf30
  CONSTR_NOTN   = ~CONSTR_NCARRY, // 0x0cf3f30c

  CONSTR_I      = 0x3cffff3c,
  CONSTR_ICARRY = 0x24dbdb24,
  CONSTR_II     = CONSTR_I & ~CONSTR_ICARRY,

  CONSTR_J      = 0xffc3c3ff,

  CONSTR_P_ZERO = 0xc0c0c0c0,  // VS SAME !!!!!
  CONSTR_P_ONE  = 0x03030303,
  CONSTR_P_DOWN = 0x0c0c0c0c,
  CONSTR_P_UP   = 0x30303030,

  CONSTR_P_EQ   = 0xc3c3c3c3,
  CONSTR_P_NEQ  = 0x3c3c3c3c,
  
  CONSTR_PP_0   = 0xaaaaaaaa,
  CONSTR_PP_1   = 0x55555555,
};

struct {
  sparse_automaton_t *transition_sparse;
} eq_types_data[EQ_TYPES] = {{0}};

#if STATE_SIZE == 4
static const int skein_rot[8][2] = {
  {14, 16},
  {52, 57},
  {23, 40},
  {5 , 37},
  {25, 33},
  {46, 12},
  {58, 22},
  {32, 32},
};
static const int skein_perm[4] = {0, 3, 2, 1};
#elif STATE_SIZE == 8
static const int skein_rot[8][4] = {
  {46, 36, 19, 37},
  {33, 27, 14, 42},
  {17, 49, 36, 39},
  {44, 9 , 54, 56},
  {39, 30, 34, 24},
  {13, 50, 10, 17},
  {25, 29, 39, 43},
  {8 , 35, 56, 22},
};
static const int skein_perm[8] = {2, 1, 4, 7, 6, 5, 0, 3};
#elif STATE_SIZE == 16
static const int skein_rot[8][8] = {
  {24, 13, 8 , 47, 8 , 17, 22, 37},
  {38, 19, 10, 55, 49, 18, 23, 52},
  {33, 4 , 51, 13, 34, 41, 59, 17},
  {5 , 20, 48, 41, 47, 28, 16, 25},
  {41, 9 , 37, 31, 12, 47, 44, 30},
  {16, 34, 56, 51, 4 , 53, 42, 41},
  {31, 44, 47, 46, 19, 42, 44, 25},
  {9 , 48, 35, 52, 23, 31, 37, 20},
};
static const int skein_perm[16] = {0, 9, 2, 13, 6, 11, 4, 15, 10, 7, 12, 3, 14, 5, 8, 1};
#else
#error I can haz Skein parameters?
#endif


char* constr_to_char(state_bf x) {
  switch (x) {
  case CONSTR_EQ:      return  "-";
  case CONSTR_NEQ:     return  "x";
  case CONSTR_UNKOWN:  return  "?";
  case CONSTR_SAME:    return  "=";
  case CONSTR_XSAME:   return  "<";
  case CONSTR_DIFF:    return  "!";
  case CONSTR_XDIFF:   return  ">";
  case CONSTR_ZERO:    return  "0";
  case CONSTR_UP:      return  "u";
  case CONSTR_ONE:     return  "1";
  case CONSTR_DOWN:    return  "n";
  case CONSTR_X:       return  "X";
  case CONSTR_CARRY:   return  "/";
  case CONSTR_NCARRY:  return  "N";
  case CONSTR_UCARRY:  return  "U";

  case CONSTR_NOTN:    return  "M";
  case CONSTR_NOTU:    return  "V";

  case CONSTR_I:       return  "I";
  case CONSTR_ICARRY:  return  "[";
  case CONSTR_II:      return  "]";
  case CONSTR_J:       return  "J";

  case CONSTR_Y:       return  "\\";
  case CONSTR_X3:      return  "3";
  case CONSTR_X5:      return  "5";
  case CONSTR_X7:      return  "7";
  case CONSTR_XA:      return  "A";
  case CONSTR_XB:      return  "B";
  case CONSTR_XC:      return  "C";
  case CONSTR_XD:      return  "D";
  case CONSTR_XE:      return  "E";

  case CONSTR_IMPOSSIBLE: return "#";

  default:;
    static char buf[11];
    snprintf (buf, sizeof(buf), "(%08x)", x);
    return buf;
  }
};

enum constraints constr_rotation_safe(enum constraints x) {
  uint32_t y = 0;
  for (uint32_t mask=0xff; mask; mask<<=8) {
    if (x & mask)
      y |= mask;
  }
  return y;
};

enum constraints constr_rotation_safe1(enum constraints x) {
  uint32_t y = 0;
  for (uint32_t mask=0xf; mask; mask<<=4) {
    if (x & mask)
      y |= mask;
  }
  return y;
};

enum constraints constr_rotation_safe2(enum constraints x) {
  uint32_t y = 0;
  for (uint32_t mask=0x3; mask; mask<<=2) {
    if (x & mask)
      y |= mask;
  }
  return y;
};

void print_reg(reg *r, int verb) {
  
  // Forget redundant information

  reg r2;
  memcpy(&r2, r, sizeof(reg));

#define idx(x) (((x)+WORD_SIZE)%WORD_SIZE)

  for (int i=WORD_SIZE-1; i>=0; i--) {
    
    state_bf x = 0;
    
    for (int j=0; j<8; j++) {
      if (r->bits[idx(i-1)] & (0xf << (4*j)))
        x |= 1<<j;
    }
    x *= 0x01010101;
    
    if ((~r->bits[i] & x & constr_rotation_safe(r->bits[i])) == 0)
      r2.bits[i] = constr_rotation_safe(r2.bits[i]);
    else if ((~r->bits[i] & x & constr_rotation_safe1(r->bits[i])) == 0)
      r2.bits[i] = constr_rotation_safe1(r2.bits[i]);
    else if ((~r->bits[i] & x & constr_rotation_safe2(r->bits[i])) == 0)
      r2.bits[i] = constr_rotation_safe2(r2.bits[i]);

    char *s = constr_to_char(r2.bits[i]);
    if (s[0] != '(' || verb) {
      printf("%s", s);
    } else {
      int z = 4*__builtin_popcountl(r->bits[i] & x) / __builtin_popcountl(x);
      char s[5] = {'�', '�', '�', '�', '�'};
      printf ("%c", s[z]);
    }

  }

#undef idx
   
  /* for (int i=WORD_SIZE-1; i>=0; i--) { */
  /*   printf ("%s", constr_to_char(r2.bits[i])); */
  /* } */
}

#define SPARSE_SIZE 16
#define SPARSE_PAR 3

int eq_count_upto(equation *eq) {

  sparse_automaton_t *at = eq_types_data[eq->t].transition_sparse;
  if (at->data == NULL) {
    fprintf (stderr, "Error: transition automaton not defined.\n");
    return -1;
  }

  int npar = at->nb_params;
  // int npar = SPARSE_PAR;
  int nst  = at->nb_states;
  parameter *in = eq->p;

  state_bf (*aa)[SPARSE_SIZE][npar+1] = (void*) at->data;

  struct reg par0[npar];
  for (int k=0; k<npar; k++) {
    memcpy(&par0[k], in[k].r, sizeof(struct reg));
    par0[k].bits[(0+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe  (par0[k].bits[(0+in[k].rot) % WORD_SIZE]);
    par0[k].bits[(1+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe2 (par0[k].bits[(1+in[k].rot) % WORD_SIZE]);
  }

  //  int p[WORD_SIZE+1][nst];
  int (*p)[nst] = malloc(sizeof(int)*(WORD_SIZE+1)*nst);
  memset (p, 0, sizeof(int)*(WORD_SIZE+1)*nst);
  p[0][0] = 1;
  for (int i=0; i<WORD_SIZE; i++) {
    int ok=0;
    for (int j=0; j<nst; j++) {
      if (p[i][j]) {
        for (int x=0; x<SPARSE_SIZE; x++) {
          int k;
          for (k=0; k<npar; k++) {
            if (!(par0[k].bits[(i+in[k].rot) % WORD_SIZE] & aa[j][x][k]))
              break;
          }
          if (k == npar) {
            p[i+1][aa[j][x][npar]] = 1;
            ok = 1;
          }
        }
      }
    }
    if (!ok) {
      free(p);
      return i;
    }
  }

  free(p);
  return WORD_SIZE;
}

int eq_compatible(equation *eq) {
  return eq_count_upto(eq) == WORD_SIZE;
}

double eq_count(equation *eq) {

  sparse_automaton_t *at = eq_types_data[eq->t].transition_sparse;
  if (at->data == NULL) {
    fprintf (stderr, "Error: transition automaton not defined.\n");
    return -1;
  }

  int npar = at->nb_params;
  int nst  = at->nb_states;
  int sparse_size = at->sparse_size;
  parameter *in = eq->p;

  state_bf (*aa)[sparse_size][npar+1] = (void*) at->data;

  struct reg par0[npar];
  for (int k=0; k<npar; k++) {
    memcpy(&par0[k], in[k].r, sizeof(struct reg));
    par0[k].bits[(0+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe  (par0[k].bits[(0+in[k].rot) % WORD_SIZE]);
    par0[k].bits[(1+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe2 (par0[k].bits[(1+in[k].rot) % WORD_SIZE]);
  }

  //  bignum p[WORD_SIZE+1][nst];
  bignum (*p)[nst] = malloc(sizeof(bignum)*(WORD_SIZE+1)*nst);
  memset (p, 0, sizeof(bignum)*(WORD_SIZE+1)*nst);
  p[0][0] = 1;
  for (int i=0; i<WORD_SIZE; i++) {
    int ok=0;
    for (int j=0; j<nst; j++) {
      if (p[i][j]) {
        for (int x=0; x<sparse_size; x++) {
          int k;
          for (k=0; k<npar; k++) {
            if (!(par0[k].bits[(i+in[k].rot) % WORD_SIZE] & aa[j][x][k]))
              break;
          }
          if (k == npar) {
            p[i+1][aa[j][x][npar]] += p[i][j];
            ok = 1;
          }
        }
      }
    }
    if (!ok) {
      free(p);
      return 0;
    }
  }

  bignum ret = 0;
  for (int i=0; i<nst; i++)
    ret += p[WORD_SIZE][i];

  free(p);
  return (double) ret;
}

void print_equation (equation *eq) {
  print_reg(eq->p[0].r, 0);
  printf (" [%2i] ", eq->p[0].rot);
  printf (" %c ", eq->t == EQ_XOR? '^': '+');
  print_reg(eq->p[1].r, 0);
  printf (" [%2i] ", eq->p[1].rot);
  printf (" = ");
  print_reg(eq->p[2].r, 0);
  printf (" [%2i] ", eq->p[2].rot);
  printf (" (%i) <", eq_compatible(eq));

  double p0 = eq_count(eq);
  // Count the number of possible values for each parameter
  sparse_automaton_t *at = eq_types_data[eq->t].transition_sparse;
  int npar = at->nb_params;
  double counts[npar];
  double prod = 0;
  for (int i=0; i<npar; i++) {
    equation ee = {
      { { eq->p[i].r, 0 } },
      EQ_COUNT, 0, 0
    };
    counts[i] = eq_count(&ee);
    prod += log(counts[i]);
  }
  
  // Now compute probabilities with a random choice a a given parameter
  for (int i=0; i<npar; i++) {
    printf ("C%i: %4.1f; ", i,
            (-log(p0*counts[i])+prod)/log(2));
  }
  printf (">\n");

}

void print_equation_arxtools (syst *s, equation *eq) {
#define index(x) ((int)((x) - s->regs))
  printf ("@state x%02i%%%02i = ", index(eq->p[2].r), eq->p[2].rot);
  printf ("x%02i%%%02i", index(eq->p[0].r), (WORD_SIZE-eq->p[0].rot)%WORD_SIZE);
  printf (" %c ", eq->t == EQ_XOR? '^': '+');
  printf ("x%02i%%%02i : ", index(eq->p[1].r), (WORD_SIZE-eq->p[1].rot)%WORD_SIZE);
  print_reg(eq->p[2].r, 1);
  printf (";\n");
#undef index
}

void mark_dirty (reg* r) {
  for (int i=0; i<r->nb_eq; i++) {
    r->eq[i]->dirty = 1;
  }
}

int eq_count_propagate(equation *eq) {

  sparse_automaton_t *at = eq_types_data[eq->t].transition_sparse;
  if (at->data == NULL) {
    fprintf (stderr, "Error: transition automaton not defined.\n");
    return -1;
  }

  int npar = at->nb_params;
  // int npar = SPARSE_PAR;
  int nst  = at->nb_states;
  parameter *in = eq->p;

  state_bf (*aa)[SPARSE_SIZE][npar+1] = (void*) at->data;

  struct reg par0[npar];
  for (int k=0; k<npar; k++) {
    memcpy(&par0[k], in[k].r, sizeof(struct reg));
    par0[k].bits[(0+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe  (par0[k].bits[(0+in[k].rot) % WORD_SIZE]);
    par0[k].bits[(1+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe2 (par0[k].bits[(1+in[k].rot) % WORD_SIZE]);
  }
  //  int p[WORD_SIZE+1][nst];
  int (*p)[nst] = malloc(sizeof(int)*(WORD_SIZE+1)*nst);
  memset (p, 0, sizeof(int)*(WORD_SIZE+1)*nst);
  p[0][0] = 1;
  for (int i=0; i<WORD_SIZE; i++) {
    int ok=0;
    for (int j=0; j<nst; j++) {
      if (p[i][j]) {
        for (int x=0; x<SPARSE_SIZE; x++) {
          int k;
          for (k=0; k<npar; k++) {
            if (!(par0[k].bits[(i+in[k].rot) % WORD_SIZE] & aa[j][x][k]))
              break;
          }
          if (k == npar) {
            p[i+1][aa[j][x][npar]] = 1;
            ok = 1;
          }
        }
      }
    }
    if (!ok) {
      free(p);
      return -1;
    }
  }

  for (int j=0; j<nst; j++) {
    if (p[WORD_SIZE][j]==1)
      p[WORD_SIZE][j]=2;
  }

  struct reg par2[npar];
  memset(par2, 0, sizeof(par2));

  for (int i=WORD_SIZE-1; i>=0; i--) {
    for (int j=0; j<nst; j++) {
      if (p[i][j]) {
        for (int x=0; x<SPARSE_SIZE; x++) {
          int k;
          for (k=0; k<npar; k++) {
            if (!(par0[k].bits[(i+in[k].rot) % WORD_SIZE] & aa[j][x][k]))
              break;
          }
          if (k == npar && p[i+1][aa[j][x][npar]] == 2) {
            p[i][j] = 2;
            for (k=0; k<npar; k++) {
              par2[k].bits[(i+in[k].rot) % WORD_SIZE] |= aa[j][x][k];
            }
          }
        }
      }
    }
  }

  free(p);

  int new = 0;

  int newr[npar];
  memset(newr, 0, sizeof(newr));

  for (int k=0; k<npar; k++) {
    par2[k].bits[(0+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe  (par2[k].bits[(0+in[k].rot) % WORD_SIZE]);
    par2[k].bits[(1+in[k].rot) % WORD_SIZE] =
      constr_rotation_safe2 (par2[k].bits[(1+in[k].rot) % WORD_SIZE]);

    for (int i=0; i<WORD_SIZE; i++) {
      state_bf n = in[k].r->bits[i] & par2[k].bits[i];
      if (n != in[k].r->bits[i]) {
        in[k].r->bits[i] = n;
        new ++;
        newr[k]++;
      }
    }
  }
  
  assert(eq_compatible(eq));

  for (int k=0; k<npar; k++) {
    if (newr[k])
      mark_dirty(in[k].r);
  }

  eq->dirty = 0;

  return new;
}

int propagate_eq (equation *eq) {
  //  static int done = 0;
  //  if (!eq_compatible(eq))
  //    return -1;

  //  printf ("Propagate (%4i) ", done++);
  //  print_equation(eq);

  return eq_count_propagate(eq);
}

void init_reg (reg *r) {
  r->eq[0] = NULL;
  memset(r->bits, -1, sizeof(r->bits));
}

void reg_add_eq(reg* r, equation* e) {
  assert (r->nb_eq + 1 < MAX_EQUATIONS);
  r->eq[r->nb_eq++] = e;
}

void new_regs(syst *s, reg *x[], int n) {
  assert(s->nb_regs+n < s->max_regs);
  for (int i=0; i<n; i++) {
    reg *r = &s->regs[s->nb_regs++];
    init_reg(r);
    x[i] = r;
  }
}

void set_type(equation *eq, enum eq_type t) {
  eq->t = t;
}

void set_diff(reg *r, word d) {
  for (int i=0; i<WORD_SIZE; i++) {
    r->bits[i] = d&1? CONSTR_NEQ: CONSTR_EQ;
    d>>=1;
  }
}

void set_diff2(reg *r, word d) {
  for (int i=0; i<WORD_SIZE; i++) {
    r->bits[i] &= d&1? CONSTR_NEQ: CONSTR_EQ;
    d>>=1;
  }
}

void set_val(reg *r, word d) {
  for (int i=0; i<WORD_SIZE; i++) {
    r->bits[i] = d&1? CONSTR_ONE: CONSTR_ZERO;
    d>>=1;
  }
}

void set_val1(reg *r, word d) {
  for (int i=0; i<WORD_SIZE; i++) {
    r->bits[i] = d&1? CONSTR_XC: CONSTR_X3;
    d>>=1;
  }
}

void add_mix (syst *s, reg *a, reg *b, reg *c, reg *d, int r, enum eq_type t_add) {
  assert (s->nb_eqs+2  < s->max_eqs);
  reg_pair p = {c, d};
  equation *add = &s->eqs[s->nb_eqs];
  equation *xor = &s->eqs[s->nb_eqs+1];
  s->nb_eqs +=2;

  add->exists   = 1;
  add->dirty    = 1;
  set_type(add, t_add);
  add->p[0].r   = a;
  add->p[0].rot = 0;
  add->p[1].r   = b;
  add->p[1].rot = 0;
  add->p[2].r   = p.a;
  add->p[2].rot = 0;
  reg_add_eq(a  , add);
  reg_add_eq(b  , add);
  reg_add_eq(p.a, add);


  xor->exists   = 1;
  xor->dirty    = 1;
  set_type(xor, EQ_XOR);
  xor->p[1].r   = p.a;
  xor->p[1].rot = 0;
  xor->p[0].r   = b;
  xor->p[0].rot = WORD_SIZE-r;
  xor->p[2].r   = p.b;
  xor->p[2].rot = 0;
  reg_add_eq(p.a, xor);
  reg_add_eq(b  , xor);
  reg_add_eq(p.b, xor);
}

void add_keyadd (syst *s, reg *a, reg *k, reg *b, enum eq_type t_add) {
  assert (s->nb_eqs+1  < s->max_eqs);
  equation *add = &s->eqs[s->nb_eqs++];

  add->exists   = 1;
  add->dirty    = 1;
  set_type(add, t_add);
  add->p[0].r   = a;
  add->p[0].rot = 0;
  add->p[1].r   = k;
  add->p[1].rot = 0;
  add->p[2].r   = b;
  add->p[2].rot = 0;
  reg_add_eq(a, add);
  reg_add_eq(k, add);
  reg_add_eq(b, add);
}

void add_op (syst *s, reg *a, reg *b, reg *c, enum eq_type op) {
  assert (s->nb_eqs+1  < s->max_eqs);
  equation *xor = &s->eqs[s->nb_eqs++];

  xor->exists   = 1;
  xor->dirty    = 1;
  set_type(xor, op);
  xor->p[0].r   = a;
  xor->p[0].rot = 0;
  xor->p[1].r   = b;
  xor->p[1].rot = 0;
  xor->p[2].r   = c;
  xor->p[2].rot = 0;
  reg_add_eq(a, xor);
  reg_add_eq(b, xor);
  reg_add_eq(c, xor);
}

reg_state add_round (syst *s, reg_state q0, int i, enum eq_type t_add) {
  reg_state q;
  new_regs(s, q.x, STATE_SIZE);

  for (int j=0; j<STATE_SIZE; j+=2) {
    add_mix (s, q0.x[j], q0.x[j+1],
             q.x[skein_perm[j]], q.x[skein_perm[j+1]],
             (skein_rot[i & 7][j/2]) % WORD_SIZE, t_add);
  }
  return q;
}


void free_syst(syst* s) {
  free(s->regs);
  free(s->eqs);
}

void print_syst_arxtools (syst *s) {
  printf("@conf wordsize = 64;\n"
         "@conf linesize = 64;\n\n"
         "@vbox;\n"
         "@group;\n"
         "@vbox;\n");
  int done[s->nb_regs];
  memset(done, 0, sizeof(done));

  void do_reg(int i) {
    if (done[i])
      return;

    equation *e = NULL;
    for (int j=0; j<s->nb_eqs; j++) {
      if (s->eqs[j].p[2].r == &s->regs[i])
        e = &s->eqs[j];
    }
    if (e) {
      do_reg(e->p[0].r - s->regs);
      do_reg(e->p[1].r - s->regs);
      print_equation_arxtools(s, e);
    } else {
      printf ("@state x%02i : ", i);
      print_reg(&s->regs[i], 1);
      printf (";\n");
    }
    done[i] = 1;
  }

  for (int i=0; i<s->nb_regs; i++) {
    do_reg(i);
    if (i%4 == 3 && i+1 < s->nb_regs) {
      printf ("@end;\n@end;\n@group;\n@vbox;\n");
    }
  }

  printf("@end;\n@end;\n@end;\n");
  fflush(stdout);
}

void print_syst (syst *s) {
#if 0
  for (int i=0; i<s->nb_eqs; i++) {
    printf ("<%2i> ", i);
    print_equation(&(s->eqs[i]));
  }
  fflush(stdout);
#endif
  print_syst_arxtools(s);
}

void dump_syst_partial (syst *s, int start, int stop) {
  for (int i=start; i<stop; i++) {
    fwrite(s->regs[i].bits, sizeof(s->regs[i].bits), 1, stderr);
  }
  fflush(stderr);
}

void dump_syst (syst *s) {
  dump_syst_partial(s, 0, s->nb_regs);
}

void load_syst_partial (syst *s, int start, int stop) {
  for (int i=start; i<stop; i++) {
    fread(s->regs[i].bits, sizeof(s->regs[i].bits), 1, stdin);
  }
}

void load_syst (syst *s) {
  load_syst_partial (s, 0, s->nb_regs);
}

int propagate_syst (syst *s) {
  //  printf ("*** Input:\n");
  //  print_syst(s);
  int todo = 1;
  while (todo) {
    todo = 0;
    for (int i=0; i<s->nb_eqs; i++) {
      while (s->eqs[i].dirty) {
        int t = 0;
        if ((t = propagate_eq (&s->eqs[i])) > 0) {
          //  print_syst(s);
          todo = 1;
        } else if (t == -1) {
          return -1;
        }
      }
    }
  }
  return 0;
}

syst copy_syst(syst *s) {
  syst t;
  t.max_eqs  = t.nb_eqs  = s->nb_eqs;
  t.max_regs = t.nb_regs = s->nb_regs;
  t.regs = malloc(t.max_regs * sizeof(reg));
  t.eqs  = malloc(t.max_eqs  * sizeof(equation));
  memcpy(t.regs, s->regs, t.max_regs * sizeof(reg));
  memcpy(t.eqs , s->eqs , t.max_eqs  * sizeof(equation));

  /* static int dbg = 0; */
  /* if (dbg == 0) { */
  /*   dbg++; */
  /*   printf ("System size: %i [%i+%i]\n", */
  /*           t.max_regs * sizeof(reg) + t.max_eqs  * sizeof(equation), t.max_regs, t.max_eqs); */
  /* } */
  return t;
}

void copy_syst_into(syst *dest, syst* src) {
  memcpy(dest->regs, src->regs,
         MIN(src->max_regs,dest->max_regs) * sizeof(reg));
  memcpy(dest->eqs , src->eqs ,
         MIN(src->max_eqs ,dest->max_eqs ) * sizeof(equation));
}

int path_force (syst *s, int guess_start, int guess_max) {

  syst bck = copy_syst(s);
  int new = 0;

  for (int n = guess_start; n<guess_max; n++) {
    for (int b = 0; b < WORD_SIZE; b++) {
    same_bit:
      if (__builtin_popcountl(s->regs[n].bits[b]) > 1) {
        for (int i=0; i<CSTR_BITS; i++) {
          if (s->regs[n].bits[b] & (1UL<<i)) {
            s->regs[n].bits[b] = (1UL<<i);
            mark_dirty(&s->regs[n]);
            
            if (propagate_syst(s) == -1) {
              copy_syst_into(s, &bck);
              s->regs[n].bits[b] ^= (1UL<<i);
              
              printf ("Forced constraint: %i.%i.%i\n", n, b, i);
      
              if (propagate_syst(s) == -1) {
                free_syst(&bck);
                return -1;
              }

              copy_syst_into(&bck, s); // Keep extra constraint
              new++;
              goto same_bit;
            }
            copy_syst_into(s, &bck);
          }
        }
      }
    }
  }

  free_syst(&bck);

  return new;
}

int path_search (syst *s, int* do_guess, int cur_guess,
                 int bit, state_bf mask1, state_bf mask2, float p) {

  // Propagate current system
  if (propagate_syst(s) == -1)
    return 0;

  if (bit == WORD_SIZE) {
    if (mask1 == CONSTR_EQ) {
      printf (".");
      fflush(stdout);
      return path_search(s, do_guess, 0, 0, CONSTR_XC, CONSTR_X3, p);
    } else {
      // WIN!
      /* printf ("!"); */
      /* fflush(stdout); */
      printf ("\nFound one solution!  :-)\n");
      print_syst(s);
      //      exit(0);
      return 1;
    }
  }

  if (do_guess[cur_guess] == -1) {
    // Goto next bit

    return path_search (s, do_guess, 0, bit+1, mask1, mask2, p);
  }

  int guess_nb = do_guess[cur_guess];

  syst bck = copy_syst(s);

  int r0 = (1.0*random()/RAND_MAX) >= p;

  for (int z=0; z<2; z++) {
    int t = 0;
    switch(z^r0) {
    case 0:
      // Try setting to mask1
      s->regs[guess_nb].bits[bit] &= mask1;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search (s, do_guess, cur_guess+1, bit, mask1, mask2, p);
      
      copy_syst_into(s, &bck);
      break;

    case 1:
      // Try setting to mask2
      s->regs[guess_nb].bits[bit] &= mask2;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search (s, do_guess, cur_guess+1, bit, mask1, mask2, p);
      
      copy_syst_into(s, &bck);
      break;
    }
    if (t) {
      free_syst(&bck);
      return t;
    }
  }

  free_syst(&bck);
  return 0;
}


static int count = 0;
static int best_bit = 0;

int path_search2 (syst *s, word *hint, word *best,
                  int* do_guess, int cur_guess, int bit, int* do_find) {

  if (count++ > 4096) {
    return 0;
  }

  // Propagate current system
  if (propagate_syst(s) == -1)
    return 0;

  if (bit > best_bit) {
    best_bit = bit;
    //    printf("Best: %2i (@%i)\n", best_bit, count);
    //    fflush(stdout);

    for (int i=0; do_guess[i] != -1; i++) {
      best[i] = 0;
      for (int j=0; j<best_bit; j++) {
        if (s->regs[do_guess[i]].bits[j] & CONSTR_NEQ)
          best[i] |= 1ULL << j;
      }
    }
  }

  if (bit == WORD_SIZE) {
    // WIN!
    /* printf ("."); */
    /* fflush(stdout); */
    static int c = 0;
    printf ("Signed path #%i:\n", ++c);
    print_syst(s);
    //    int z;
    //    for (z=0; do_guess[z] != -1; z++);
    //    do_guess[z] = 0;

#if 0
    double k = 0;
    for (int i=0; i<4; i++) {
      equation ee = {
        { { &s->regs[i], 0} },
        EQ_COUNT, 0, 0,
      };
      double c = eq_count(&ee);
      k += log(c)/log(2);
    }

    printf ("Valid keys: %f\n", k);
#else
    equation ee = {
      { { &s->regs[0], 0 }, { &s->regs[1], 0 },
	{ &s->regs[2], 0 }, { &s->regs[3], 0 },
	{ &s->regs[4], 0 }, { &s->regs[11], 0 } },
      EQ_XOR5X, 0, 0
    };

    double k = log(eq_count(&ee))/log(2);
    printf ("Valid keys: %f\n", k);

    double st = 0;
    for (int i=0; i<4; i++) {
      equation ee = {
        { { &s->regs[48+i], 0} },
        EQ_COUNT, 0, 0,
      };
      double c = eq_count(&ee);
      st += log(c)/log(2);
    }

    printf ("Valid states: %f\n", st);

    double p = 0;
      
    for (int i=0; i<s->nb_eqs; i++) {
      int j;
      if (i>=6 && i<38) {
        // Compute backward cost of rounds 0-6
        j = 0;
      } else if (i>=38 && i<62) {
        // Compute forward cost of rounds 7-11
        j = 2;
      } else {
        // Ignore extra equations
        continue;
      }

      equation* eq = &(s->eqs[i]);
      double p0 = eq_count(eq);
      int npar = 3;
      double counts[npar];
      double prod = 0;
      for (int i=0; i<npar; i++) {
        equation ee = {
          { { eq->p[i].r, 0 } },
          EQ_COUNT, 0, 0
        };
        counts[i] = eq_count(&ee);
        prod += log(counts[i]);
      }
      
      double d = (-log(p0*counts[j])+prod)/log(2);
      // printf ("// %f\n", d);
      p += d;
    }
    
    printf ("Cost: %f\n", p);
    printf ("Number of solutions: %f\n", k+st-p);
#endif

    int x= path_search(s, do_find, 0, 0, CONSTR_XC, CONSTR_X3, 0.5);
    //    do_guess[z] = -1;
    printf ("<Search for pairs done>\n");
    count = 4096;
    return x;
  }

  if (do_guess[cur_guess] == -1) {
    // Goto next bit

    return path_search2 (s, hint, best, do_guess, 0, bit+1, do_find);
  }

  int guess_nb = do_guess[cur_guess];

  syst bck = copy_syst(s);

  int r0 = (random()&31) == 0;
  r0 ^= (hint[cur_guess] & (1ULL<<bit)) != 0;

  for (int z=0; z<2; z++) {
    int t = 0;
    switch(z^r0) {
    case 0:
      // Try setting to inactive
      s->regs[guess_nb].bits[bit] &= CONSTR_EQ;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search2 (s, hint, best, do_guess, cur_guess+1, bit, do_find);
      
      copy_syst_into(s, &bck);
      break;

    case 1:;
      // Try setting to active
      int r = random()&1;
      s->regs[guess_nb].bits[bit] &= r? CONSTR_UP: CONSTR_DOWN;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search2 (s, hint, best, do_guess, cur_guess+1, bit, do_find);
      
      copy_syst_into(s, &bck);
      
      if (t) {
        free_syst(&bck);
        return t;
      }

      s->regs[guess_nb].bits[bit] &= r? CONSTR_DOWN: CONSTR_UP;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search2 (s, hint, best, do_guess, cur_guess+1, bit, do_find);
      
      copy_syst_into(s, &bck);
      break;
    }
    if (t) {
      free_syst(&bck);
      return t;
    }
  }
  free_syst(&bck);

  return 0;
}

int path_search0 (syst *s, int* do_guess, int cur_guess, int bit) {

  // Propagate current system
  if (propagate_syst(s) == -1)
    return 0;

  if (bit == WORD_SIZE) {
    // WIN!
    return 1;
  }

  if (do_guess[cur_guess] == -1) {
    // Goto next bit

    return path_search0 (s, do_guess, 0, bit+1);
  }

  int guess_nb = do_guess[cur_guess];

  syst bck = copy_syst(s);

  int r0 = (random()&15) == 0;

  for (int z=0; z<2; z++) {
    int t = 0;
    switch(z^r0) {
    case 0:
      // Try setting to inactive
      s->regs[guess_nb].bits[bit] &= CONSTR_EQ;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search0 (s, do_guess, cur_guess+1, bit);
      break;

    case 1:;
      // Try setting to active
      int r = random()&1;
      s->regs[guess_nb].bits[bit] &= CONSTR_NEQ;
      mark_dirty(&(s->regs[guess_nb]));
      t = path_search0 (s, do_guess, cur_guess+1, bit);
      break;
    }
    if (t) {
      free_syst(&bck);
      return t;
    } else {
        copy_syst_into(s, &bck);
    }
  }
  free_syst(&bck);

  return 0;
}



int path_init () {

  syst s;
  s.nb_eqs  = s.nb_regs  = 0;
  s.max_eqs = s.max_regs = 256;
  s.regs = calloc(s.max_regs, sizeof(reg));
  s.eqs  = calloc(s.max_eqs , sizeof(equation));

  reg *key[8];
  new_regs(&s, key, 8);
  reg *tmp[8];
  new_regs(&s, tmp, 8);
  
  add_op(&s, key[0], key[1], tmp[0], EQ_XOR);
  add_op(&s, key[2], key[3], tmp[1], EQ_XOR);
  add_op(&s, tmp[0], tmp[1], tmp[2], EQ_XOR);
  add_op(&s, key[4], tmp[2], tmp[3], EQ_XOR);
  set_val(tmp[3], 0x1BD11BDAA9FC1A22ULL);

  set_val(tmp[4], 1);
  set_val(tmp[5], 2);
  add_op(&s, key[4], tmp[4], key[5], EQ_ADD);
  add_op(&s, key[0], tmp[5], key[6], EQ_ADD);

  set_diff(key[0], 0);
  set_diff(key[1], 0);
  set_diff(key[2], 0);
  set_diff(key[3], 0);

  reg_state qin;
  new_regs(&s, qin.x, STATE_SIZE);
  set_diff(qin.x[0], (1ULL<<58)+(1ULL<<44));
  set_diff(qin.x[1], (1ULL<<44));
  set_diff(qin.x[2], 0);
  set_diff(qin.x[3], 0);
 

  reg_state qt1  = add_round(&s, qin , 0, EQ_LIN);
  reg_state qt2  = add_round(&s, qt1 , 1, EQ_LIN);
  reg_state qt3  = add_round(&s, qt2 , 2, EQ_LIN);
  reg_state qt4  = add_round(&s, qt3 , 3, EQ_LIN);

  reg_state qtk1;
  new_regs(&s, qtk1.x, STATE_SIZE);
  for (int i=0; i<STATE_SIZE-1; i++)
    add_keyadd(&s, qt4.x[i], key[(i+1)%5], qtk1.x[i], EQ_LIN);
  add_keyadd(&s, qt4.x[3], key[5], qtk1.x[3], EQ_LIN);

  reg_state qt5  = add_round(&s, qtk1, 4, EQ_LIN);
  reg_state qt6  = add_round(&s, qt5 , 5, EQ_ADD);
  reg_state qt7  = add_round(&s, qt6 , 6, EQ_ADD);
  reg_state qt8  = add_round(&s, qt7 , 7, EQ_ADD);

  reg_state qtk2;
  new_regs(&s, qtk2.x, STATE_SIZE);
  for (int i=0; i<STATE_SIZE-1; i++)
    add_keyadd(&s, qt8.x[i], key[(i+2)%5], qtk2.x[i], EQ_ADD);
  add_keyadd(&s, qt8.x[3], key[6], qtk2.x[3], EQ_ADD);

  reg_state qt9  = add_round(&s, qtk2, 0, EQ_ADD);
  reg_state qt10 = add_round(&s, qt9 , 1, EQ_ADD);
  reg_state qt11 = add_round(&s, qt10, 2, EQ_LIN);
  reg_state qout = add_round(&s, qt11, 3, EQ_LIN);

  set_diff(qout.x[0], (1ULL<<58)+(1ULL<<44));
  set_diff(qout.x[1], (1ULL<<44));
  set_diff(qout.x[2], 0);
  set_diff(qout.x[3], 0);

  eq_types_data[EQ_LIN] = eq_types_data[EQ_XOR];

  propagate_syst(&s);

  eq_types_data[EQ_LIN] = eq_types_data[EQ_ADD];

  propagate_syst(&s);

#if 0
#if 0
  int x;
  while ((x = path_force(&s, 0, s.nb_regs))) {
    printf ("Forced %i constraints.\n", x);
  }

  if (x == -1)
    printf ("System incompatible.\n");

  dump_syst(&s);

#else
  load_syst(&s);
#endif
#endif

  // print_syst(&s);

  //  return path_search(&s, start, 0, start+4, 0, CONSTR_EQ, CONSTR_NEQ);

#define index(x) ((x) - s.regs)

  int do_init[] = {
    index( qt5.x[0]), index( qt5.x[1]), index( qt5.x[2]), index( qt5.x[3]),
    //    index(qt11.x[0]), index(qt11.x[1]), index(qt11.x[2]), index(qt11.x[3]), 
    -1,
  };

  int do_search[] = {
    index(qt6.x[0]), index(qt6.x[1]), index(qt6.x[2]), index(qt6.x[3]),
    index(qt8.x[0]), index(qt8.x[1]), index(qt8.x[2]), index(qt8.x[3]), 
    index(qtk2.x[1]), index(qtk2.x[3]),
    -1
  };

  int do_find[] = {
    index( qt8.x[0]), index( qt8.x[1]), index( qt8.x[2]), index( qt8.x[3]), 
    index(qtk2.x[0]), index(qtk2.x[1]), index(qtk2.x[2]), index(qtk2.x[3]),
    -1
  };

#undef index

  word hint[s.nb_regs];
  memset (hint, 0, sizeof(hint));
  word best[s.nb_regs];

  word *a = hint, *b = best;

#if 0
   path_search0(&s, do_init, 0, 0);
   printf ("Starting point:\n");
   print_syst(&s);

  int x;
  while ((x = path_force(&s, 0, s.nb_regs))) {
    printf ("Forced %i constraints.\n", x);
  }

  if (x == -1) {
    printf ("System incompatible.\n");
    exit (-1);
  }
  dump_syst_partial(&s, 0, 76);
#else
  load_syst_partial(&s, 0, 76);

  for (int i=0; i<s.nb_regs; i++) {
    mark_dirty(&s.regs[i]);
  }
  if (propagate_syst(&s) == -1) {
    print_syst(&s);
    fprintf (stderr, "Bad path\n");
    return 3;
  }
#endif

  //  printf ("Starting point:\n");
  //  print_syst(&s);

  int prev = 0;

  for (;;) {
    // Global state
    count = 0;
    best_bit = 0;

    int x = path_search2(&s, a, b, do_search, 0, 0, do_find);
    /*
    if (x) {
      double k = 0;
      for (int i=0; i<4; i++) {

        equation ee = {
          { { key2.x[i], 0} },
          EQ_COUNT, 0, 0
        };
        
        k += log(eq_count(&ee))/log(2);
      }
      printf ("Valid keys: %f\n", k);
    }
    */
    printf ("%2i/%2i\n", best_bit, prev);

    if (best_bit >= prev) {
      prev = best_bit;
      // Swap best and hint

      printf ("Hint:");
      for (int i=0; do_search[i] != -1; i++) {
        printf (" %016llx", b[i]);
      }
      printf ("\n");

      word *t = a;
      a = b;
      b = t;
    }
    fflush(stdout);
  }
}


size_t mmap_at (char *file, sparse_automaton_t **at) {
  int fd = open(file, O_RDONLY);
  
  if (fd < 0) {
    char buffer[32];
    snprintf (buffer, sizeof(buffer), "open %s", file);
    perror (buffer);
    return -1;
  }
  
  struct stat st;
  fstat(fd, &st);
  size_t size = st.st_size;
  *at = mmap(NULL, size,
             PROT_READ, MAP_SHARED, fd, 0);
  if (*at == MAP_FAILED) {
    perror ("mmap:");
    return -1;
  }
  return size;
}

int main (int argc, char* argv[]) {

  srandom(getpid()+time(NULL));
  uint32_t seed;
  if (argc > 1)
    seed = strtoul(argv[1], NULL, 16);
  else
    seed = random();
  printf ("Seed: %08x\n", seed);
  srandom(seed);
  assert(WORD_SIZE <= MAX_WORD_SIZE);
  
  mmap_at("add-xx.fsm", &eq_types_data[EQ_ADD].transition_sparse);
  mmap_at("xor-xx.fsm", &eq_types_data[EQ_XOR].transition_sparse);
  mmap_at("count-xx.fsm", &eq_types_data[EQ_COUNT].transition_sparse);
  mmap_at("xor5x.fsm", &eq_types_data[EQ_XOR5X].transition_sparse);

  path_init();

}
