typedef uint8_t  byte;
typedef uint32_t u32;
typedef uint64_t u64;
typedef uint16_t tword;
void BuildTableSCShRMCS();
void PermutationOnByte(byte* b, int R);
